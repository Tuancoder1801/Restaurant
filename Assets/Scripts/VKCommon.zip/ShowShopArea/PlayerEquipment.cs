using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerEquipment : MonoBehaviour
{       
    public SkinPlayerId id;
    public Animator animator;
    public Transform tranGlass;
}
