using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectorEquipment : MonoBehaviour
{
    public SkinRobotId skinRobotId;
    public Animator anim;
}
